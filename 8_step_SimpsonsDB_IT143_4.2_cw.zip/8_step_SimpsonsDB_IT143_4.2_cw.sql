
-- Step #1 -- Ask a Question
-- Q: How much money did Marge and Homer Simpson spend during 1990 at the store?

-- Step #2 -- Begin creating an answer
-- A: Using their names from the Family Data database and pulling spending
-- from the planet_express DB, calculate all spending that isn't payments
-- for the year 1990

-- Step #3 -- Ad Hoc Query
USE Simpsons;

SELECT fd.Name, FORMAT(SUM(pe.Amount),'C','en-us') AS 'TotalSpent'
FROM [Simpsons].[dbo].[Family_Data] AS fd
  INNER JOIN [Simpsons].[dbo].[Planet_Express] AS pe 
  ON pe.Card_Member=fd.name
  WHERE DATEPART(year,pe.Date) = 1990 AND pe.Description NOT LIKE '%PAYMENT%'
 GROUP BY fd.name
 ;

 -- Step #4 -- Setup View dbo.v_Simpsons_Spend

DROP VIEW IF EXISTS dbo.v_Simpsons_Spend
GO

CREATE VIEW dbo.v_Simpsons_Spend
AS 
SELECT fd.Name, FORMAT(SUM(pe.Amount),'C','en-us') AS 'TotalSpent'
FROM [Simpsons].[dbo].[Family_Data] AS fd
  INNER JOIN [Simpsons].[dbo].[Planet_Express] AS pe 
  ON pe.Card_Member=fd.name
  WHERE DATEPART(year,pe.Date) = 1990 AND pe.Description NOT LIKE '%PAYMENT%'
 GROUP BY fd.name
 GO
 ;

 -- Step #5 -- Create table dbo.t_Simpsons_Spend
DROP TABLE IF EXISTS dbo.t_Simpsons_Spend
GO

SELECT *
INTO dbo.t_Simpsons_Spend
FROM dbo.v_Simpsons_Spend;
GO

-- Step 6 -- Truncate and Reload data
TRUNCATE TABLE dbo.t_Simpsons_Spend
GO

INSERT INTO dbo.t_Simpsons_Spend
	SELECT *
	FROM dbo.v_Simpsons_Spend AS v;
GO

-- Step 7 -- Create Stored Procedure dbo.usp_Simpsons_Spend

CREATE PROCEDURE dbo.usp_Simpsons_Spend
AS

BEGIN
	-- Reload data from view --
	TRUNCATE TABLE dbo.t_Simpsons_Spend

	INSERT INTO dbo.t_Simpsons_Spend
	SELECT *
	FROM dbo.v_Simpsons_Spend AS v;


	-- View results from new table --
	SELECT *
	FROM dbo.t_Simpsons_Spend
	;
	
	END;
GO

-- Step 8 -- Execute Stored Procedure usp_Simpsons_Spend

EXEC dbo.usp_Simpsons_Spend;