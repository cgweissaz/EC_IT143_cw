/* -- Step #1 -- Ask a question
What are the top most populated cities in the world 
by continent?


-- Step #2 -- Begin by answering the question
Using the world database, let's get the City name, 
City Population, Country Name, Country Continent, 
Country Population, and select the highest population city per continent.

*/

-- Step #3 -- Create an Ad Hoc Query
USE world;
GO

SELECT *
FROM (SELECT 
	city.Name AS 'CityName', 
	FORMAT(city.Population,'N','en-us')  AS 'TopPop', 
	co.name AS 'CountryName', 
	co.Continent, 
	FORMAT(co.Population,'N','en-us') AS 'CountryPop',
	ROW_NUMBER() OVER (PARTITION BY co.continent ORDER BY city.Population DESC) rownum
FROM [dbo].[city] AS city
	INNER JOIN [dbo].[country] AS co 
		ON co.Code=city.CountryCode
	) t
WHERE rownum = 1
;

 -- Step #4 -- Setup View dbo.v_HighestCityPop_by_Cont

DROP VIEW IF EXISTS dbo.v_HighestCityPop_by_Cont
GO

CREATE VIEW dbo.v_HighestCityPop_by_Cont
AS 
SELECT *
FROM (SELECT 
	city.Name AS 'CityName', 
	FORMAT(city.Population,'N','en-us')  AS 'TopPop', 
	co.name AS 'CountryName', 
	co.Continent, 
	FORMAT(co.Population,'N','en-us') AS 'CountryPop',
	ROW_NUMBER() OVER (PARTITION BY co.continent ORDER BY city.Population DESC) rownum
FROM [dbo].[city] AS city
	INNER JOIN [dbo].[country] AS co 
		ON co.Code=city.CountryCode
	) t
WHERE rownum = 1
;
GO

 -- Step #5 -- Create table HighestCityPop_by_Cont
DROP TABLE IF EXISTS dbo.t_HighestCityPop_by_Cont
GO

SELECT *
INTO dbo.t_HighestCityPop_by_Cont
FROM dbo.v_HighestCityPop_by_Cont;
GO

-- Step 6 -- Truncate and Reload data
TRUNCATE TABLE dbo.t_HighestCityPop_by_Cont
GO

INSERT INTO dbo.t_HighestCityPop_by_Cont
	SELECT *
	FROM dbo.v_HighestCityPop_by_Cont AS v;
GO

-- Step 7 -- Create Stored Procedure dbo.usp_Simpsons_Spend

CREATE PROCEDURE dbo.usp_HighestCityPop_by_Cont
AS

BEGIN
	-- Reload data from view --
	TRUNCATE TABLE dbo.t_HighestCityPop_by_Cont

	INSERT INTO dbo.t_HighestCityPop_by_Cont
	SELECT *
	FROM dbo.v_HighestCityPop_by_Cont AS v;


	-- View results from new table --
	SELECT *
	FROM dbo.t_HighestCityPop_by_Cont
	;
	
	END;
GO

-- Step 8 -- Execute Stored Procedure usp_Simpsons_Spend

EXEC usp_HighestCityPop_by_Cont;