-- Step #1 -- Ask a Question
-- Q: Which of our customers, and from which countries, 
-- order from our drink/beverages category?

-- Step #2 -- Begin creating an answer
-- A: Using the customer, orders, order detail, products, and categories tables
-- query for customers who ordered products from category #1 'beverages'

-- Step #3 -- Ad Hoc Query
USE EC_IT143_DA;

SELECT c.customerid, c.customername, c.country, count(o.orderid) AS '# orders'
, cat.categoryid, cat.categoryname
FROM customers AS c 
	INNER JOIN dbo.orders AS o ON c.customerid=o.customerid
	INNER JOIN dbo.order_details AS od ON o.orderid=od.orderid
	INNER JOIN dbo.products AS p ON od.productid=p.productid
	INNER JOIN dbo.categories AS cat ON p.categoryid=cat.categoryid
WHERE cat.categoryid=1
GROUP BY c.customerid,c.customername, c.country, cat.categoryid, cat.categoryname
ORDER BY c.country;
GO

-- Step #4 -- Setup View dbo.v_Bev_Customers

DROP VIEW IF EXISTS dbo.v_Bev_Customers
GO

CREATE VIEW dbo.v_Bev_Customers
AS 
SELECT c.customerid, c.customername, c.country, count(o.orderid) AS '# orders'
, cat.categoryid, cat.categoryname
FROM customers AS c 
	INNER JOIN dbo.orders AS o ON c.customerid=o.customerid
	INNER JOIN dbo.order_details AS od ON o.orderid=od.orderid
	INNER JOIN dbo.products AS p ON od.productid=p.productid
	INNER JOIN dbo.categories AS cat ON p.categoryid=cat.categoryid
WHERE cat.categoryid=1
GROUP BY c.customerid,c.customername, c.country, cat.categoryid, cat.categoryname;
GO

-- Step #5 -- Create table t.Bev_Customers
DROP TABLE IF EXISTS dbo.t_Bev_Customers
GO

SELECT *
INTO dbo.t_Bev_Customers
FROM dbo.v_Bev_Customers;
GO

-- Step 6 -- Truncate and Reload data
TRUNCATE TABLE dbo.t_Bev_Customers
GO

INSERT INTO dbo.t_Bev_Customers
	SELECT *
	FROM dbo.v_Bev_Customers AS v;
GO

-- Step 7 -- Create Stored Procedure dbo.usp.Bev_Customers

CREATE PROCEDURE dbo.usp_Bev_Customers
AS

BEGIN
	-- Reload data from view --
	TRUNCATE TABLE dbo.t_Bev_Customers

	INSERT INTO dbo.t_Bev_Customers
	SELECT *
	FROM dbo.v_Bev_Customers AS v;

	-- View results from new table --
	SELECT *
	FROM dbo.t_Bev_Customers
	ORDER BY Country;
	
	END;
GO

-- Step 8 -- Execute Stored Procedure usp_Bev_Customers

EXEC dbo.usp_Bev_Customers;